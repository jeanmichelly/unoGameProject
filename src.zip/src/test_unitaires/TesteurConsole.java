package test_unitaires;

import java.util.Scanner;
import model.BoardModel;
import model.card.ColorModel;
import model.deck.DiscardPileModel;

public class TesteurConsole {
    
    public static void play_HumanPlayerModel () {
        Scanner sc = new Scanner(System.in);
         if ( BoardModel.getUniqueInstance().getPlayer().getPlayerHand().hasPlayableCard() ) {
            w1: while (true) {
                System.out.println("Que voulez vous faire ? (j/n)");
                switch(sc.next()) {
                    case "j":
                        BoardModel.getUniqueInstance().getPlayer().putDownCard();
                        break w1;
                    case "n":
                        BoardModel.getUniqueInstance().getPlayer().notToPlay();
                        w2: while (true) {
                            System.out.println("Que voulez vous faire ?");
                            switch (sc.next()) {
                                case "j":
                                    BoardModel.getUniqueInstance().getPlayer().putDownCard();
                                    break w2;
                                case "n":
                                    BoardModel.getUniqueInstance().moveCursorToNextPlayer();
                                    break w2;
                            }
                        }
                        break w1;
                }
            }
         }
         else {
             while (true) {
                 System.out.println("Pas de carte jouable, piocher carte");
                 BoardModel.getUniqueInstance().getPlayer().pickCard();
                 if ( BoardModel.getUniqueInstance().getPlayer().getPlayerHand().hasPlayableCard() ) { // à changer pour performance
                     w3: while (true) {
                         System.out.println("Que voulez vous faire ?");
                         switch (sc.next()) {
                             case "j":
                                 BoardModel.getUniqueInstance().getPlayer().putDownCard();
                                 break w3;
                             case "n":
                                 BoardModel.getUniqueInstance().moveCursorToNextPlayer();
                                 break w3;
                         }
                     }
                 }
                 else
                     BoardModel.getUniqueInstance().moveCursorToNextPlayer();
             }
         }
    }

    public static void chooseColor_HumanPlayerModel () {
        w : while (true) {
            System.out.println("Veuillez choisir une couleur('j', 'r', 'b', 'v')");
            Scanner sc = new Scanner(System.in);
            String choice = sc.next();
            switch ( choice ) {
                case "j":
                    DiscardPileModel.getUniqueInstance().peek().setColor(ColorModel.YELLOW);
                    break w;
                case "r":
                    DiscardPileModel.getUniqueInstance().peek().setColor(ColorModel.RED);
                    break w;
                case "b":
                    DiscardPileModel.getUniqueInstance().peek().setColor(ColorModel.BLUE);
                    break w;
                case "v":
                    DiscardPileModel.getUniqueInstance().peek().setColor(ColorModel.GREEN);
                    break w;
            }
        }
    }
}
