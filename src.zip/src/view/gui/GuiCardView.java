package view.gui;

public class GuiCardView {

}
