package model.card;

public interface ComparablePlayableCardModel {

    public int hasCardPlayable(CardModel card);
    public boolean equals(CardModel card);
    
}
