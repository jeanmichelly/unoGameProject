package model.player.strategy;


public class PriorityColorStrategyModel implements StrategyModel {

    @Override
    public void execute () {        
    }
    
}
