package model.player.strategy;


public class RandomStrategyModel implements StrategyModel {

    @Override
    public void execute () {
        
    }
    
}
