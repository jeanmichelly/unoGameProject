package model.player.strategy;


public class PriorityNumberStrategyModel implements StrategyModel {

    @Override
    public void execute () {        
    }
    
}
