package model.player.strategy;


public class PrioritySpecialityStrategyModel implements StrategyModel {

    @Override
    public void execute () {        
    }
    
}
