package model.player.strategy;

public interface StrategyModel {

    public void execute ();
    
}
