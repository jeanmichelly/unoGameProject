package model.player;

import test_unitaires.TesteurConsole;

public class HumanPlayerModel extends PlayerModel {
    
    public HumanPlayerModel (String pseudonym) {
        super(pseudonym);
    }
    
    @Override
    public void play () {
        TesteurConsole.play_HumanPlayerModel();
    }

    public void putDownCard() {
        System.out.println("putDownCard");
    }
    
    public void chooseColor () {
        TesteurConsole.chooseColor_HumanPlayerModel();
    }
    
    public void notToPlay() {
        System.out.println("notToPlay");
    }

    @Override
    public void signalUno() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void againstUno() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void challengeAgainstWildDrawFourCard() {
        // TODO Auto-generated method stub
        
    }
    
}
